# Voice Studio Offline — native Android

This is a **native offline Android application**, not a Streamlit web wrapper. No server, internet, account, API or paid library is required after installation.

## Included now
- Microphone recording (maximum 60 seconds; 16 kHz mono PCM)
- Lightweight high-pass filter, gentle gate, peak normalization
- Local procedural backing loops with Gospel, Afro-pop, Hip-hop and Rock presets
- Voice+music mixing, preview through speakers, WAV export into `Music/VoiceStudio`
- Source code in Java / Android SDK; no third-party runtime dependencies

## Important limitations
- Instrumentals are **algorithmically synthesized**, not AI-generated, not studio-quality arrangements, and do not automatically follow the pitch or tempo of the singer.
- The noise reduction is a simple filter/gate rather than `noisereduce` or neural speech enhancement.
- Exports WAV (not MP3). Supports Android 10+.
- The APK has **not** been compiled and tested here; run a build and test recording/playback on a real device before sharing.

## Build an installable APK for free using GitHub (phone friendly)
1. Create a public GitHub repository, e.g. `voice-studio-offline`.
2. Upload the **contents** of this folder into the root of the repository, keeping `.github/workflows/android-apk.yml` in the right location. GitHub's web interface may not conveniently upload nested folders on mobile; uploading files via a Git app or using `git` is another option.
3. In GitHub, go to **Actions → Build Offline Android APK → Run workflow** (or commit to `main`).
4. Open the completed workflow run → **Artifacts → voice-studio-offline-apk**.
5. Extract the artifact ZIP, tap `app-debug.apk`, and permit installation from your file manager if Android asks.
6. Open **Voice Studio Offline**, allow microphone access, record, process, preview and save.

You can also open the project in Android Studio (JDK 17, Android SDK 35) and run `gradle :app:assembleDebug` if Gradle is installed.

**Security**: GitHub Actions produces a debug-signed build for personal testing. For public app-store release, create a signed release build, update branding/privacy disclosures, and test compatibility. Recordings are processed locally and are not uploaded by this app.
