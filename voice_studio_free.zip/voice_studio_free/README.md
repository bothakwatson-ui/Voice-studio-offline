# Voice Studio (free, open-source demo)

A fully operational Streamlit prototype that records microphone audio, denoises and gates voice, synthesizes basic royalty-free background accompaniment locally (NOT AI), overlays with pydub, and downloads WAV/MP3.

## Local quick start

Python 3.11+ recommended. Install FFmpeg on your OS and ensure `ffmpeg` is in PATH.

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
streamlit run app.py
```

## Streamlit Community Cloud

1. Publish the files in a public GitHub repository.
2. Deploy from https://share.streamlit.io/ with `app.py` as the main file.
3. `packages.txt` asks Streamlit Cloud to install FFmpeg for MP3 encoding.
4. Give the browser microphone permission. HTTPS is provided by the host.

## Hugging Face Spaces

Create a **Docker** Space and include the Dockerfile in this project. HF's supported runtimes can change; Docker is the explicit deployment method here. Use the provided Dockerfile.

## Optional AI music integration

`generate_ai_instrumental(prompt, duration_seconds, token)` is intentionally a **placeholder**. To use an actual text-to-music model:

1. Host a permitted model, such as MusicGen, on an appropriate GPU-enabled inference service, or find a hosted inference provider that explicitly offers text-to-music generation.
2. Check usage, model-weight licensing, quotas and pricing. `facebook/musicgen-small` is **not currently deployed** on Hugging Face's standard Inference Providers and its weights are CC-BY-NC-4.0 (noncommercial).
3. Implement an endpoint call in `generate_ai_instrumental`, converting returned audio to a WAV byte string. Supply endpoint credentials via Streamlit secrets or environmental variables, never hard-code tokens.
4. In the `if process` block, replace `instrumental = generate_free_backing(prompt, duration)` with `instrumental = generate_ai_instrumental(prompt, duration, token=...)`.
5. Models generated from text prompts do not necessarily infer key, tempo or harmonic progression of an a cappella vocal. To align automatically, add pitch/key and beat detection and conditioning or user controls.

A free CPU Streamlit host generally cannot run MusicGen weights at practical speed, and third-party hosted GPU inference is not guaranteed to be free. The included synthesizer is deliberately runnable without a model key.

## Notes

- WAV input only; microphone capture uses Streamlit's browser recorder.
- Maximum input duration: 120 seconds to limit CPU/RAM use on free hosting.
- Processing happens on the server, in memory, and is not uploaded to an AI endpoint in the default app.
- For serious multitrack work, add tempo/key detection, latency alignment, chord changes, and a limiter.
- Source code can be released under MIT; third-party dependencies and model weights keep their separate licenses.
